package ru.iopump.qa.allure.entity;

import org.junit.Test;

public class ReportEntityTest {

    @Test
    public void sizeKB() {
    }

    @Test
    public void checkUrl() {
    }
}